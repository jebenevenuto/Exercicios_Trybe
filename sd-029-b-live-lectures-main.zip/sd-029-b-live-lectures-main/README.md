# Repositório de aulas ao vivo para estudantes da Turma 29 - Tribo B 😎

Este repositório armazena os códigos e scripts fornecidos durante as aulas ao vivo pelos especialistas da Trybe.

## Começando

Basta clonar o repositório.

```sh
git clone git@github.com:tryber/sd-029-b-live-lectures.git
```
---

### Estrutura

Todos os conteúdos dados em aulas estarão no seu respectivo Pull Request!

---
